package com.otoclick.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(30), dp(20), dp(20))
        }

        fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(12), 0, dp(2))
        }

        fun field(value: String) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(value)
        }

        root.addView(label("OtoTıkla", 28f, true))
        root.addView(label("Otomatik tıklayıcı + otomatik kaydırıcı"))

        root.addView(label(
            "1) Aşağıdaki butondan Erişilebilirlik ayarlarını aç.\n" +
            "2) OtoTıkla servisini aç ve izin ver.\n" +
            "3) Ekranda yüzen panel çıkar. Kırmızı daireyi hedef noktaya sürükle.\n" +
            "4) Panelden TIK/KAYDIR modunu seç, ▶ ile başlat."
        ))

        root.addView(Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(label("Ayarlar", 20f, true))

        root.addView(label("Tıklama / kaydırma aralığı (ms)"))
        val fInterval = field(p.getLong("interval", 500L).toString())
        root.addView(fInterval)

        root.addView(label("Tekrar sayısı (0 = sonsuz)"))
        val fCount = field(p.getInt("maxCount", 0).toString())
        root.addView(fCount)

        root.addView(label("Kaydırma mesafesi (ekranın %'si)"))
        val fDist = field(p.getInt("swipeDist", 40).toString())
        root.addView(fDist)

        root.addView(label("Kaydırma süresi (ms)"))
        val fDur = field(p.getLong("swipeDur", 300L).toString())
        root.addView(fDur)

        root.addView(Button(this).apply {
            text = "Kaydet"
            setOnClickListener {
                p.edit()
                    .putLong("interval", (fInterval.text.toString().toLongOrNull() ?: 500L).coerceAtLeast(20L))
                    .putInt("maxCount", (fCount.text.toString().toIntOrNull() ?: 0).coerceAtLeast(0))
                    .putInt("swipeDist", (fDist.text.toString().toIntOrNull() ?: 40).coerceIn(5, 90))
                    .putLong("swipeDur", (fDur.text.toString().toLongOrNull() ?: 300L).coerceAtLeast(50L))
                    .apply()
                Toast.makeText(this@MainActivity, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(label("Not: Kaydırma yönü panelden değişir (↑ ↓ ← →). Dikey kaydırmada kırmızı dairenin yatay konumu, yatay kaydırmada dikey konumu kullanılır.").apply {
            gravity = Gravity.START
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
