package com.otoclick.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ClickService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: View? = null
    private var marker: View? = null
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var markerLp: WindowManager.LayoutParams

    private var playBtn: TextView? = null
    private var modeBtn: TextView? = null
    private var dirBtn: TextView? = null

    private var running = false
    private var mode = 0   // 0 = tık, 1 = kaydır
    private var dir = 0    // 0 yukarı, 1 aşağı, 2 sol, 3 sağ
    private var count = 0

    private val arrows = arrayOf("↑", "↓", "←", "→")
    private val markerSize get() = dp(56)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildUi()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopRun()
    }

    override fun onDestroy() {
        stopRun()
        removeUi()
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun btn(t: String) = TextView(this).apply {
        text = t
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun drag(handle: View, lp: WindowManager.LayoutParams, view: View) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        handle.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = ev.rawX; ty = ev.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (ev.rawX - tx).toInt()
                    lp.y = sy + (ev.rawY - ty).toInt()
                    try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                }
            }
            true
        }
    }

    private fun buildUi() {
        if (panel != null) return
        val dm = resources.displayMetrics

        // Hedef işaretçisi (kırmızı daire)
        val m = TextView(this).apply {
            text = "+"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x66FF3B30)
                setStroke(dp(2), Color.WHITE)
            }
        }
        markerLp = overlayParams(markerSize, markerSize).apply {
            x = dm.widthPixels / 2 - markerSize / 2
            y = dm.heightPixels / 2 - markerSize / 2
        }
        drag(m, markerLp, m)
        wm.addView(m, markerLp)
        marker = m

        // Kontrol paneli
        val handle = btn("☰")
        val play = btn("▶")
        val modeB = btn("TIK")
        val dirB = btn("↑").apply { visibility = View.GONE }
        val close = btn("✕")
        playBtn = play; modeBtn = modeB; dirBtn = dirB

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xEE222222.toInt())
            }
            setPadding(dp(6), dp(4), dp(6), dp(4))
            addView(handle); addView(play); addView(modeB); addView(dirB); addView(close)
        }
        panelLp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        ).apply {
            x = dp(16)
            y = dp(120)
        }
        drag(handle, panelLp, p)

        play.setOnClickListener { if (running) stopRun() else startRun() }
        modeB.setOnClickListener {
            if (running) stopRun()
            mode = 1 - mode
            modeB.text = if (mode == 0) "TIK" else "KAYDIR"
            dirB.visibility = if (mode == 1) View.VISIBLE else View.GONE
        }
        dirB.setOnClickListener {
            dir = (dir + 1) % 4
            dirB.text = arrows[dir]
        }
        close.setOnClickListener {
            stopRun()
            removeUi()
            Toast.makeText(this, "Servis kapatıldı", Toast.LENGTH_SHORT).show()
            disableSelf()
        }

        wm.addView(p, panelLp)
        panel = p
    }

    private fun removeUi() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { marker?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        marker = null
    }

    private fun setMarkerTouchable(touchable: Boolean) {
        val m = marker ?: return
        markerLp.flags = if (touchable) {
            markerLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            markerLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try { wm.updateViewLayout(m, markerLp) } catch (_: Exception) {}
    }

    // ---------- Çalıştırma ----------

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            act()
            count++
            val p = prefs()
            val max = p.getInt("maxCount", 0)
            if (max > 0 && count >= max) {
                stopRun()
                return
            }
            val interval = p.getLong("interval", 500L)
            val delay = if (mode == 1) maxOf(interval, p.getLong("swipeDur", 300L) + 100L) else interval
            handler.postDelayed(this, delay)
        }
    }

    private fun startRun() {
        if (running) return
        running = true
        count = 0
        setMarkerTouchable(false)
        playBtn?.text = "⏸"
        handler.post(tick)
    }

    private fun stopRun() {
        running = false
        handler.removeCallbacks(tick)
        if (panel != null) {
            setMarkerTouchable(true)
            playBtn?.text = "▶"
        }
    }

    private fun act() {
        val p = prefs()
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val cx = (markerLp.x + markerSize / 2).toFloat()
        val cy = (markerLp.y + markerSize / 2).toFloat()

        val path = Path()
        var dur = 50L

        if (mode == 0) {
            path.moveTo(cx, cy)
        } else {
            dur = p.getLong("swipeDur", 300L)
            val pct = p.getInt("swipeDist", 40) / 100f
            val half = pct / 2f
            when (dir) {
                0 -> { path.moveTo(cx, h * (0.5f + half)); path.lineTo(cx, h * (0.5f - half)) }
                1 -> { path.moveTo(cx, h * (0.5f - half)); path.lineTo(cx, h * (0.5f + half)) }
                2 -> { path.moveTo(w * (0.5f + half), cy); path.lineTo(w * (0.5f - half), cy) }
                else -> { path.moveTo(w * (0.5f - half), cy); path.lineTo(w * (0.5f + half), cy) }
            }
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
